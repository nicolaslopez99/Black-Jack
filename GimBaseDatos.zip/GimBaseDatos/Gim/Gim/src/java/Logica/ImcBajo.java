/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;
import java.util.*;

/**
 *
 * @author Antonio
 */
public class ImcBajo extends GanarMusculo{
    public ImcBajo(){
        setPullOver();
        setAbdominales();
        setLumbares();
        setIsquiotibiales();
        crearRutina();
    }

    public String getAbdominales() {
        return abdominales;
    }

    public String getPullOver() {
        return pullOver;
    }

    public String getLumbares() {
        return lumbares;
    }

    public String getIsquiotibiales() {
        return isquiotibiales;
    }
    

    public void setAbdominales() {
        int numero = (int) (Math.random()*5)+10;
        String abdominales = Integer.toString(numero);
        this.abdominales = abdominales;
    }

    public void setPullOver() {
        int numero = (int) (Math.random()*5)+10;
        String pullOver = Integer.toString(numero);
        this.pullOver = pullOver;
    }

    public void setLumbares() {
        int numero = (int) (Math.random()*5)+10;
        String lumbares = Integer.toString(numero);
        this.lumbares = lumbares;
    }

    public void setIsquiotibiales() {
        int numero = (int) (Math.random()*5)+10;
        String isquiotibiales = Integer.toString(numero);
        this.isquiotibiales = isquiotibiales;
    }

    public void setCalentamiento() {
        this.calentamiento = "cardio por 20 minutos";
    }

    public void setEstiramiento() {
        this.estiramiento = "estirar por 30 minutos";
    }

    public void setCantidadDias() {
        String dias[]= {"lunes","martes","miercoles","jueves","viernes"};
        int numero = (int) (Math.random()*5);
        int numero1 = 0;
        int numero2 =0;
        do{
            numero1 = (int) (Math.random()*5);
        } while(numero1==numero);
        do{
            numero2 = (int) (Math.random()*5);
        }while(numero2 == numero || numero2 == numero1 || numero == numero1);
        String dias1[]= new String[3];
        dias1[0]= dias[numero];
        dias1[1]= dias[numero1];
        dias1[2]= dias[numero2];
        
        String diasf = dias1[0]+" "+dias1[1]+" "+dias1[2];
        
        this.cantidadDias = diasf;
    }
    public String crearRutina(){
        String ejercicios[] = {"pullOver","lumbares","isquiotibiales","abdominales"};
        //String rutina[] = new String [6];
        //String rutina1[] = new String[7];
        ArrayList<String> rutina = new ArrayList<String>();
        ArrayList<String> rutina1 = new ArrayList<String>();
        //String rutinad[] = new String[6];
        String rutinaf="";
                
        int numero = (int) (Math.random()*4);
        int numero1 = (int) (Math.random()*4);
        int numero2 = (int) (Math.random()*4);
        int aux = 0;
        
            do{
                numero1 = (int) (Math.random()*4);
            } while(numero1==numero);
            do{
                numero2 = (int) (Math.random()*4);
                
            }while(numero2 == numero || numero2 == numero1 || numero == numero1);

            rutina.add(ejercicios[numero]);
            rutina.add(ejercicios[numero1]);
            rutina.add(ejercicios[numero2]);


            for(int i =0 ; i<=2;i++){
                if(rutina.get(i).equals("pullOver")){

                    //rutina1[aux]="pullOver";
                    //rutina1[aux+1]= getPullOver();
                    //aux=aux+2;
                    rutina1.add("pullOver");
                    rutina1.add(getPullOver());
                } else if(rutina.get(i).equals("lumbares")){
                    rutina1.add("lumbares");
                    rutina1.add(getLumbares());

                    //rutina1[aux]="lumbares";
                    //rutina1[aux+1]= getLumbares();
                    //aux=aux+2;
                } else if (rutina.get(i).equals("isquiotibiales")){
                    rutina1.add("isquiotibiales");
                    rutina1.add(getIsquiotibiales());

                    //rutina1[aux]="isquiotibiales";
                    //rutina1[aux+1]= getIsquiotibiales();
                    //aux=aux+2;
                } else if (rutina.get(i).equals("abdominales")){
                    
                    rutina1.add("abdominales");
                    rutina1.add(getAbdominales());

                    //rutina1[aux]="abdominales";
                    //rutina1[aux+1]= getAbdominales();
                    //aux=aux+2;
                }
                
            }
            for(int i = 0;i<rutina1.size();i++){
                rutinaf = rutinaf+rutina1.get(i);
                //rutinaf = rutina1[0]+" "+rutina1[1]+" "+rutina1[2]+" "+rutina1[3]+" "+rutina1[4]+" "+rutina1[5];
            }
        
        return rutinaf;
        
    }
    

}
