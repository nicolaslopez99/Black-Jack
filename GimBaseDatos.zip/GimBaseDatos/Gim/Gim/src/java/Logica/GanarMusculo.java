/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;

/**
 *
 * @author Antonio
 */
public class GanarMusculo extends Rutina{
    protected String abdominales;
    protected String pullOver;
    protected String lumbares;
    protected String isquiotibiales;


    
}
