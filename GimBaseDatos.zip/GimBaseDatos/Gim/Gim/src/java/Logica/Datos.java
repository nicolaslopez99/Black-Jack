/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;

/**
 *
 * @author Antonio
 */
public class Datos {
    
    protected String nombre;
    protected double altura;
    protected int peso;
    protected int codigo;
    protected String Correo;
    protected int edad;
    int id;
    
    protected String calentamiento;
    protected String estiramiento;  
    protected String cantidadDias;
    
    protected String rutinaf;
    
    public String  crearRutina(){
        return rutinaf;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public int getPeso() {
        return peso;
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }

    public String getCalentamiento() {
        return calentamiento;
    }

    public void setCalentamiento() {
        this.calentamiento = calentamiento;
    }

    public String getEstiramiento() {
        return estiramiento;
    }

    public void setEstiramiento() {
        this.estiramiento = estiramiento;
    }

    public String getCantidadDias() {
        return cantidadDias;
    }

    public void setCantidadDias() {
        this.cantidadDias = cantidadDias;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getCorreo() {
        return Correo;
    }

    public void setCorreo(String Correo) {
        this.Correo = Correo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    
    
}
