package GymServ;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import Logica.ImcBajo;
import Logica.Datos;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Antonio
 */

    

public class Pagina extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
   static Datos s;
   void Liskov(Datos a, String nombre, double estatura, int peso, String correo,int edad,int codigo){
        //if(a.getEjercicioMusculos().equals("musculos")){
        
        a.setAltura(estatura);
        a.setNombre(nombre);
        a.setPeso(peso);
        a.setCodigo(codigo);
        a.setCorreo(correo);
        
        
        a.setCalentamiento();
        a.crearRutina();
        a.setEstiramiento();
        a.setCantidadDias();
        
        
        
        s=a;
/*        } else{
            if(a.getEjerciciosCardio().equals("cardio")){
                a.setElevacionRodillas();
                a.setElevaciones();
                a.setPuntillas();
                a.setSentadillas();

                a.setRepPuntillas();
                a.setRepSentadillas();
                a.setRepElevacionRodillas();
                a.setRepElevaciones();

                a.setAltura(estatura);
                a.setNombre(nombre);
                a.setPeso(peso);

                s=a;
            }   
            }*/ 
    }
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        double estatura = (int) Math.pow(Integer.parseInt(request.getParameter("estatura")), 2);
        int peso = Integer.parseInt(request.getParameter("peso"));
        double imc = peso/estatura;
        
        
        if(imc <18.5 && request.getParameter("desidir").equals("subir")){
                ImcBajo c = new ImcBajo();
                Liskov(c,request.getParameter("nombre"),Double.parseDouble(request.getParameter("estatura")),Integer.parseInt(request.getParameter("peso")),request.getParameter("correo"),Integer.parseInt(request.getParameter("edad")),Integer.parseInt(request.getParameter("cod")));
            } else{
                if(imc < 25){
                    
                }
                else{
                    if(imc <30){
                        
                    }
                }
            }
        

        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>"+s.getNombre()+"</title>");
            out.println("<tr>");
            out.println("<td>peso</td>\n");			
            out.println("<td>"+s.getPeso()+"</td>");
            out.println("</tr>");
            out.println("<tr>");
            out.println("<td>estatura</td>\n");			
            out.println("<td>"+s.getAltura()+"</td>");
            out.println("</tr>");
            out.println("<tr>");
            
            out.println("<td>"+s.getCantidadDias()+"</td>\n");
            out.println(s.getCalentamiento());
            out.println("<td>"+s.crearRutina()+"</td>");
            out.println(s.getEstiramiento());
            out.println("</tr>");
            out.println("</head>");
            out.println("<body>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
