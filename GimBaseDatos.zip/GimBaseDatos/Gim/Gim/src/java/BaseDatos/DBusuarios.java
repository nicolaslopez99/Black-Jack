/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BaseDatos;

import Logica.Datos;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Estudiantes
 */
public class DBusuarios {
    
    DBConexion db;
    
    
    public DBusuarios (){
        db =new DBConexion();
    }
    public ResultSet getUsuarioById(int id) throws SQLException {
        PreparedStatement pstm = db.getConexion().prepareStatement("SELECT id, "
                + " nombre, "
                + " correo, "
                + " altura,"
                + " peso, "
                + " codigo, "
                + " edad "
                + " FROM usuarios "
                + " WHERE id = ? ");
        pstm.setInt(1, id);

        ResultSet res = pstm.executeQuery();
        /*
         res.close();	
         */

        return res;
    }
    public ResultSet getContactos() throws SQLException {
        PreparedStatement pstm = db.getConexion().prepareStatement("SELECT id, "
                + " nombre, "
                + " correo, "
                + " altura,"
                + " peso, "
                + " codigo, "
                + " edad "
                + " FROM usuarios "
                + " ORDER BY nombre, edad ");


        ResultSet res = pstm.executeQuery();
        return res;
    }
    
    public void insertarUsuario(Datos d) {
        
        try {
            PreparedStatement pstm = db.getConexion().prepareStatement("insert into usuarios (nombre, "
                    + " correo, "
                    + " altura,"
                    + " peso, "
                    + " codigo, "
                    + " edad) "
                    + " values(?,?,?,?,?,?)");
            pstm.setString(1, d.getNombre());
            pstm.setString(2, d.getCorreo());
            pstm.setString(3, Double.toString(d.getAltura()));
            pstm.setString(4, Double.toString(d.getPeso()));
            pstm.setString(5, Integer.toString(d.getCodigo()));
            pstm.setString(6, Integer.toString(d.getEdad()));

            pstm.executeUpdate();


        } catch (SQLException e) {
            System.out.println(e);
        }

    }
    public void actualizarUsuario(Datos d ) {

        try {
            PreparedStatement pstm = db.getConexion().prepareStatement("update usuarios set nombre = ?, "
                    + " correo = ?,"
                    + " altura = ?,"
                    + " peso = ?,"
                    + " codigo = ?,"
                    + " edad = ? "
                    + " where id = ?");
            pstm.setString(1, d.getNombre());
            pstm.setString(2, d.getCorreo());
            pstm.setString(3, Double.toString(d.getAltura()));
            pstm.setString(4, Double.toString(d.getPeso()));
            pstm.setString(5, Integer.toString(d.getCodigo()));
            pstm.setString(6, Integer.toString(d.getEdad()));
            pstm.setInt(7, d.getId());

            pstm.executeUpdate();


        } catch (SQLException e) {
            System.out.println(e);
        }

    }
    public void borrarUsuario(int id) {

        try {
            PreparedStatement pstm = db.getConexion().prepareStatement("delete from usuarios "
                    + " where id = ?");

            pstm.setInt(1, id);

            pstm.executeUpdate();

        } catch (SQLException e) {
            System.out.println(e);
        }

    }
    public String getMensaje() {
        return db.getMensaje();
    }
    
}
