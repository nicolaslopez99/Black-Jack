// JavaScript Document
function mostrarDiv(divId){
	document.getElementById(divId).style.visibility = 'visible';
	document.getElementById(divId).style.display = '';
}

function ocultarDiv(divId){
	document.getElementById(divId).style.visibility = 'hidden';
	document.getElementById(divId).style.display = 'none';
}

function limpiar(id){
	document.getElementById(id).value = '';
}

function changePage(action){
	var r = parseInt(document.getElementById('rows').value);
	var i = parseInt(document.getElementById('init').value);
	var s = parseInt(document.getElementById('size').value);
	var tope = i+s;
	for(h=i;h<=tope;h++){
		if(h>1 && h<=r) ocultarDiv('div_'+h);
	}
	
	if(action=='foward'){
		if(i+s<r)i += s;
	}else{
		if(i>s)i -= s; else i=2;
	}
	for(h=i;h<i+s;h++){
		if(h>1 && h<=r) mostrarDiv('div_'+h);
	}
	
	document.getElementById('init').value = i;
	document.getElementById('size').value = s;
}

function habilitarDependiente(element){
	var val = element.value;
	var objRadio = document.getElementsByName('radio_'+val);
	var lon = objRadio.length;
	if(element.checked==true){
		for(i=0;i<lon;i++){
			document.getElementsByName('radio_'+val)[i].disabled=false;
		}
	}else{
		for(i=0;i<lon;i++){
			document.getElementsByName('radio_'+val)[i].checked=false;
			document.getElementsByName('radio_'+val)[i].disabled=true;
		}
	}
	//alert ('radio_'+val);
}

